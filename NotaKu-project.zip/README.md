# NOTA-KU

Nota belanja simpel, cetak ke printer termal Bluetooth 58 mm (ESC/POS), simpan JPG & kirim ke WhatsApp.
Tampilan ada di app/src/main/assets/index.html.
