package com.notaku.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

/** Koneksi Bluetooth Classic (SPP) ke printer termal. */
@SuppressLint("MissingPermission")
class PrinterConnection(private val adapter: BluetoothAdapter?) {
    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    var address: String? = null
        private set

    val isConnected: Boolean get() = socket?.isConnected == true

    @Throws(IOException::class)
    fun connect(device: BluetoothDevice) {
        close()
        try { adapter?.cancelDiscovery() } catch (ignored: Exception) {}

        var s: BluetoothSocket? = null
        try {
            val first = device.createRfcommSocketToServiceRecord(spp)
            s = first
            first.connect()
        } catch (e: Exception) {
            try { s?.close() } catch (ignored: Exception) {}
            // Cara cadangan untuk printer yang rewel
            try {
                val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                val fb = m.invoke(device, 1) as BluetoothSocket
                s = fb
                fb.connect()
            } catch (e2: Exception) {
                try { s?.close() } catch (ignored: Exception) {}
                throw IOException("Gagal tersambung: ${e.message}")
            }
        }
        socket = s
        out = s!!.outputStream
        address = device.address
    }

    @Throws(IOException::class)
    fun write(data: ByteArray) {
        val o = out ?: throw IOException("Printer belum tersambung")
        var i = 0
        val chunk = 512
        while (i < data.size) {
            val n = minOf(chunk, data.size - i)
            o.write(data, i, n)
            o.flush()
            i += n
            Thread.sleep(20) // beri jeda agar buffer printer tidak meluap
        }
    }

    fun close() {
        try { out?.close() } catch (ignored: Exception) {}
        try { socket?.close() } catch (ignored: Exception) {}
        out = null
        socket = null
        address = null
    }
}
