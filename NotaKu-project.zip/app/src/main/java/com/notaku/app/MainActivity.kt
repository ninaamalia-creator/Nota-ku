package com.notaku.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Aplikasi NOTA-KU: tampilan dari assets/index.html (WebView),
 * cetak langsung ke printer termal Bluetooth (SPP, ESC/POS) lewat jembatan "AndroidPrinter".
 */
@SuppressLint("MissingPermission", "SetJavaScriptEnabled")
class MainActivity : Activity() {

    private lateinit var web: WebView
    private val printer by lazy { PrinterConnection(adapter()) }
    private val lock = Any()

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBlock: (() -> Unit)? = null
    private var pendingCb: String? = null
    private val reqPerm = 41
    private val reqFile = 42

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B1630")

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.addJavascriptInterface(Bridge(), "AndroidPrinter")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    startActivityForResult(Intent.createChooser(i, "Pilih file"), reqFile)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onAndroidBack && window.onAndroidBack()) ? '1' : '0'") { r ->
            if (r?.contains("1") != true) finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqFile) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    override fun onDestroy() {
        printer.close()
        super.onDestroy()
    }

    // ---------- Izin Bluetooth (Android 12+) ----------
    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun withPerm(cbId: String, block: () -> Unit) {
        if (hasBtPermission()) { block(); return }
        runOnUiThread {
            pendingBlock = block
            pendingCb = cbId
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), reqPerm)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != reqPerm) return
        val block = pendingBlock
        val cb = pendingCb
        pendingBlock = null
        pendingCb = null
        if (hasBtPermission() && block != null) {
            Thread { block() }.start()
        } else if (cb != null) {
            reply(cb, JSONObject().put("error", "Izin Bluetooth ditolak. Aktifkan di Pengaturan > Aplikasi."))
        }
    }

    private fun reply(cbId: String, res: JSONObject) = runOnUiThread {
        web.evaluateJavascript("window.__btReply(${JSONObject.quote(cbId)}, $res)", null)
    }

    // ---------- Jembatan untuk JavaScript ----------
    inner class Bridge {

        @JavascriptInterface
        fun listPrinters(cbId: String) = withPerm(cbId) {
            val res = JSONObject()
            val a = adapter()
            when {
                a == null -> res.put("error", "HP ini tidak punya Bluetooth")
                !a.isEnabled -> res.put("error", "Bluetooth mati. Nyalakan dulu.")
                else -> {
                    val arr = JSONArray()
                    try {
                        a.bondedDevices.sortedBy { it.name ?: "" }.forEach {
                            arr.put(JSONObject().put("name", it.name ?: "Tanpa nama").put("address", it.address))
                        }
                    } catch (e: Exception) {
                        res.put("error", "Tidak bisa membaca daftar Bluetooth")
                    }
                    res.put("devices", arr)
                }
            }
            reply(cbId, res)
        }

        @JavascriptInterface
        fun print(cbId: String, address: String, b64: String) = withPerm(cbId) {
            Thread {
                val res = JSONObject()
                try {
                    val a = adapter() ?: throw Exception("HP ini tidak punya Bluetooth")
                    if (!a.isEnabled) throw Exception("Bluetooth mati. Nyalakan dulu.")
                    val data = Base64.decode(b64, Base64.DEFAULT)
                    synchronized(lock) {
                        if (!printer.isConnected || printer.address != address) {
                            printer.connect(a.getRemoteDevice(address))
                        }
                        try {
                            printer.write(data)
                        } catch (e: Exception) {
                            // sambungan lama putus: sambung ulang sekali
                            printer.connect(a.getRemoteDevice(address))
                            printer.write(data)
                        }
                    }
                    res.put("ok", true)
                } catch (e: Exception) {
                    printer.close()
                    res.put("error", "Gagal mencetak. Pastikan printer menyala & tidak dipakai HP lain. (${e.message})")
                }
                reply(cbId, res)
            }.start()
        }

        @JavascriptInterface
        fun share(name: String, b64: String, mime: String) {
            runOnUiThread {
                try {
                    val dir = File(cacheDir, "share").apply { mkdirs() }
                    val f = File(dir, name)
                    f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "Bagikan"))
                } catch (e: Exception) {
                    web.evaluateJavascript("toast('Gagal membagikan file')", null)
                }
            }
        }

        /** Kirim JPG nota langsung ke chat nomor WhatsApp (format 62xxx). */
        @JavascriptInterface
        fun sendWhatsApp(phone: String, name: String, b64: String, caption: String): String {
            return try {
                val dir = File(cacheDir, "share").apply { mkdirs() }
                val f = File(dir, name)
                f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                fun intentFor(pkg: String?) = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, caption)
                    if (phone.isNotBlank()) putExtra("jid", "$phone@s.whatsapp.net")
                    if (pkg != null) setPackage(pkg)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try {
                        startActivity(intentFor(pkg))
                        return ""
                    } catch (e: android.content.ActivityNotFoundException) { /* coba berikutnya */ }
                }
                startActivity(Intent.createChooser(intentFor(null), "Kirim nota"))
                "WhatsApp tidak ditemukan, pilih aplikasi lain"
            } catch (e: Exception) {
                "Gagal mengirim: ${e.message}"
            }
        }

        /** Simpan JPG ke Galeri (folder Pictures/NotaKu). Android lama: buka menu Bagikan. */
        @JavascriptInterface
        fun saveImage(name: String, b64: String): String {
            if (Build.VERSION.SDK_INT < 29) {
                share(name, b64, "image/jpeg")
                return "Pilih tempat menyimpan gambar"
            }
            return try {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NotaKu")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("insert gagal")
                contentResolver.openOutputStream(uri)?.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                "JPG tersimpan di Galeri (Pictures/NotaKu)"
            } catch (e: Exception) {
                "Gagal menyimpan: ${e.message}"
            }
        }
    }
}
